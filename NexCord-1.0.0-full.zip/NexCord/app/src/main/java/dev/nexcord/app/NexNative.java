package dev.nexcord.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class NexNative {
    private final WebView wv;
    private final Activity activity;

    public NexNative(Activity activity, WebView wv) {
        this.activity = activity;
        this.wv = wv;
    }

    @JavascriptInterface
    public void goBack() {
        activity.runOnUiThread(() -> {
            if (wv.canGoBack()) wv.goBack();
        });
    }

    /** Copy text to Android clipboard from JS */
    @JavascriptInterface
    public void copyToClipboard(String text) {
        ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("NexCord", text));
    }

    /** Read clipboard from JS (used by paste-in-chat plugin) */
    @JavascriptInterface
    public String readClipboard() {
        ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm.hasPrimaryClip() && cm.getPrimaryClip() != null) {
            ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
            return item != null ? item.getText().toString() : "";
        }
        return "";
    }

    /** Vibrate feedback for haptic response on tap */
    @JavascriptInterface
    public void vibrate(int ms) {
        android.os.Vibrator v = (android.os.Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(Math.min(ms, 500));
    }

    /** Return NexCord version info to JS */
    @JavascriptInterface
    public String getAppInfo() {
        return "{\"name\":\"" + Constants.APP_NAME + "\",\"version\":\"" + Constants.APP_VERSION + "\"}";
    }
}
