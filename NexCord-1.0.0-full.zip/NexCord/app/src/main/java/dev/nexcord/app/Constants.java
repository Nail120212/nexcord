package dev.nexcord.app;

public class Constants {
    public static final String APP_NAME = "NexCord";
    public static final String APP_VERSION = "1.0.0";

    // NexCord JS bundle - hosted on GitHub releases
    public static final String JS_BUNDLE_URL = "https://github.com/NexCord/NexCord/releases/latest/download/nexcord.js";
    public static final String CSS_BUNDLE_URL = "https://github.com/NexCord/NexCord/releases/latest/download/nexcord.css";

    // Fallback to Vencord bundle if NexCord bundle not available
    public static final String JS_BUNDLE_FALLBACK = "https://github.com/Vendicated/Vencord/releases/download/devbuild/browser.js";
    public static final String CSS_BUNDLE_FALLBACK = "https://github.com/Vendicated/Vencord/releases/download/devbuild/browser.css";

    // Performance tuning
    public static final int WEBVIEW_CACHE_SIZE_MB = 32;
    public static final boolean HARDWARE_ACCEL = true;
}
