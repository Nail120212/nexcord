package dev.nexcord.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class VChromeClient extends WebChromeClient {
    private final MainActivity activity;

    public VChromeClient(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                     FileChooserParams fileChooserParams) {
        activity.filePathCallback = filePathCallback;
        Intent intent = fileChooserParams.createIntent();
        try {
            activity.startActivityForResult(intent, MainActivity.FILECHOOSER_RESULTCODE);
        } catch (Exception e) {
            activity.filePathCallback = null;
            return false;
        }
        return true;
    }
}
