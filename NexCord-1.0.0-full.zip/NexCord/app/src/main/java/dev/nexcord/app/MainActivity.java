package dev.nexcord.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import java.io.IOException;
import java.util.Objects;

public class MainActivity extends Activity {
    public static final int FILECHOOSER_RESULTCODE = 8485;
    private boolean wvInitialized = false;
    private WebView wv;
    private ProgressBar loadingBar;

    public ValueCallback<Uri[]> filePathCallback;

    @SuppressLint({"SetJavaScriptEnabled", "NewApi"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        // Build layout programmatically - dark bg to prevent white flash on load
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(Color.parseColor("#1e1f22")); // Discord dark bg

        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#1e1f22"));
        RelativeLayout.LayoutParams wvParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);
        root.addView(wv, wvParams);

        // Loading progress bar
        loadingBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingBar.setIndeterminate(true);
        RelativeLayout.LayoutParams pbParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, 6);
        pbParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        root.addView(loadingBar, pbParams);

        setContentView(root);

        setupWebView();
        wv.setWebViewClient(new NexWebviewClient(this, loadingBar));
        wv.setWebChromeClient(new VChromeClient(this));
        wv.addJavascriptInterface(new NexNative(this, wv), "VencordMobileNative");

        explodeAndroid();
        loadNexCord();

        Intent intent = getIntent();
        if (Objects.equals(intent.getAction(), Intent.ACTION_VIEW)) {
            Uri data = intent.getData();
            if (data != null) handleUrl(data);
        }

        wvInitialized = true;
    }

    @SuppressLint("NewApi")
    private void setupWebView() {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT); // use cache - less network = faster

        // Performance: hardware acceleration hints
        s.setRenderPriority(WebSettings.RenderPriority.HIGH);

        // Media
        s.setMediaPlaybackRequiresUserGesture(false);

        // Better text rendering on mobile
        s.setTextZoom(100);
        s.setMinimumFontSize(8);

        // Viewport: let Discord's responsive layout work correctly
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false); // disable pinch-zoom, Discord handles its own

        // Enable modern web APIs
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);

        // Hardware acceleration on the view itself
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private void loadNexCord() {
        new Thread(() -> {
            try {
                HttpClient.fetchNexCord(this);
                runOnUiThread(() -> wv.loadUrl("https://discord.com/app"));
            } catch (IOException ex) {
                Logger.e("Failed to fetch NexCord bundle", ex);
                runOnUiThread(() -> showRetryDialog(ex.getMessage()));
            }
        }).start();
    }

    private void showRetryDialog(String msg) {
        new AlertDialog.Builder(this)
                .setTitle("NexCord failed to load")
                .setMessage("Could not download the NexCord bundle:\n\n" + msg)
                .setPositiveButton("Retry", (d, w) -> loadNexCord())
                .setNegativeButton("Exit", (d, w) -> finish())
                .setCancelable(false)
                .show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && wv != null) {
            runOnUiThread(() -> wv.evaluateJavascript("VencordMobile.onBackPress()", r -> {
                if ("false".equals(r))
                    this.onBackPressed();
            }));
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode != FILECHOOSER_RESULTCODE || filePathCallback == null)
            return;

        if (resultCode != RESULT_OK || intent == null) {
            filePathCallback.onReceiveValue(null);
        } else {
            Uri[] uris;
            try {
                var clipData = intent.getClipData();
                if (clipData != null) {
                    uris = new Uri[clipData.getItemCount()];
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        uris[i] = clipData.getItemAt(i).getUri();
                    }
                } else {
                    uris = new Uri[]{intent.getData()};
                }
            } catch (Exception ex) {
                Logger.e("Error during file upload", ex);
                uris = null;
            }
            filePathCallback.onReceiveValue(uris);
        }
        filePathCallback = null;
    }

    private void explodeAndroid() {
        StrictMode.setThreadPolicy(
                new StrictMode.ThreadPolicy.Builder()
                        .permitNetwork()
                        .build()
        );
    }

    public void handleUrl(Uri url) {
        if (url != null) {
            if (!url.getAuthority().equals("discord.com")) return;
            if (!wvInitialized) {
                wv.loadUrl(url.toString());
            } else {
                wv.evaluateJavascript(
                        "Vencord.Webpack.Common.NavigationRouter.transitionTo(\"" + url.getPath() + "\")",
                        null);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent.getData();
        if (data != null) handleUrl(data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        wv.onPause();
        wv.pauseTimers(); // stop JS timers in background - saves battery
    }

    @Override
    protected void onResume() {
        super.onResume();
        wv.onResume();
        wv.resumeTimers();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        wv.stopLoading();
        wv.destroy();
    }
}
