package dev.nexcord.app;

import android.app.Activity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class NexWebviewClient extends WebViewClient {
    private final Activity activity;
    private final ProgressBar loadingBar;

    public NexWebviewClient(Activity activity, ProgressBar loadingBar) {
        this.activity = activity;
        this.loadingBar = loadingBar;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);

        // Hide loading bar
        activity.runOnUiThread(() -> loadingBar.setVisibility(View.GONE));

        if (url == null || !url.contains("discord.com")) return;

        // Inject NexCord runtime
        String runtime = HttpClient.NexCordRuntime;
        String mobileRuntime = HttpClient.NexCordMobileRuntime;

        if (runtime != null) {
            // Escape for JS string injection
            view.evaluateJavascript(runtime, null);
        }
        if (mobileRuntime != null) {
            view.evaluateJavascript(mobileRuntime, null);
        }
    }

    @Override
    public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
        activity.runOnUiThread(() -> loadingBar.setVisibility(View.VISIBLE));
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String url = request.getUrl().toString();
        // Allow Discord URLs through; external URLs open in browser
        if (url.contains("discord.com") || url.contains("discordapp.com")) {
            return false;
        }
        // Open other links in the device browser
        android.content.Intent intent = new android.content.Intent(
                android.content.Intent.ACTION_VIEW, request.getUrl());
        activity.startActivity(intent);
        return true;
    }
}
