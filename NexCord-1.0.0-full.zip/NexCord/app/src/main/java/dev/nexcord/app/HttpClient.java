package dev.nexcord.app;

import android.app.Activity;

import androidx.annotation.NonNull;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class HttpClient {
    public static final class HttpException extends IOException {
        private final HttpURLConnection conn;
        private String message;

        public HttpException(HttpURLConnection conn) {
            this.conn = conn;
        }

        @Override
        @NonNull
        public String getMessage() {
            if (message == null) {
                try (var es = conn.getErrorStream()) {
                    message = String.format(
                            Locale.ENGLISH,
                            "%d: %s (%s)\n%s",
                            conn.getResponseCode(),
                            conn.getResponseMessage(),
                            conn.getURL().toString(),
                            readAsText(es)
                    );
                } catch (IOException ex) {
                    message = "Error building message. URL: " + conn.getURL();
                }
            }
            return message;
        }
    }

    public static String NexCordRuntime;
    public static String NexCordMobileRuntime;

    public static void fetchNexCord(Activity activity) throws IOException {
        if (NexCordRuntime != null) return;

        // Load the built-in mobile bootstrap
        var res = activity.getResources();
        try (var is = res.openRawResource(R.raw.nexcord_mobile)) {
            NexCordMobileRuntime = readAsText(is);
        }

        // Try NexCord bundle first, fall back to Vencord
        String jsUrl = Constants.JS_BUNDLE_URL;
        try {
            var conn = fetch(jsUrl);
            try (var is = conn.getInputStream()) {
                NexCordRuntime = readAsText(is);
            }
        } catch (Exception e) {
            Logger.w("NexCord bundle unavailable, using Vencord fallback: " + e.getMessage());
            var conn = fetch(Constants.JS_BUNDLE_FALLBACK);
            try (var is = conn.getInputStream()) {
                NexCordRuntime = readAsText(is);
            }
        }
    }

    private static HttpURLConnection fetch(String url) throws IOException {
        var conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10_000);
        conn.setReadTimeout(30_000);
        conn.setRequestProperty("User-Agent", "NexCord/" + Constants.APP_VERSION + " Android");
        if (conn.getResponseCode() >= 300) {
            throw new HttpException(conn);
        }
        return conn;
    }

    private static String readAsText(InputStream is) throws IOException {
        try (var baos = new ByteArrayOutputStream()) {
            int n;
            byte[] buf = new byte[16384];
            while ((n = is.read(buf)) > -1) {
                baos.write(buf, 0, n);
            }
            baos.flush();
            //noinspection CharsetObjectCanBeUsed
            return baos.toString("UTF-8");
        }
    }
}
