package dev.nexcord.app;

import android.util.Log;

public class Logger {
    private static final String TAG = "NexCord";

    public static void i(String msg) { Log.i(TAG, msg); }
    public static void w(String msg) { Log.w(TAG, msg); }
    public static void e(String msg) { Log.e(TAG, msg); }
    public static void e(String msg, Throwable t) { Log.e(TAG, msg, t); }
}
