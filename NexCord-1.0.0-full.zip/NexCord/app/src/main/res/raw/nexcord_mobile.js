/**
 * NexCord Mobile Runtime v1.0.0
 * Injected into Discord WebView on every page load.
 * Extends Vencord with NexCord-exclusive mobile plugins.
 */
!(() => {
    "use strict";

    // ─── Back-press / sidebar handler (ported from Vendroid) ──────────────────
    const waitForVencord = (cb, attempts = 0) => {
        if (typeof Vencord !== "undefined" && Vencord?.Webpack?.Common) {
            cb();
        } else if (attempts < 100) {
            setTimeout(() => waitForVencord(cb, attempts + 1), 200);
        } else {
            console.warn("[NexCord] Vencord not found after 20s, skipping init");
        }
    };

    let isSidebarOpen = false;

    waitForVencord(() => {
        const { findLazy, Common, onceReady } = Vencord.Webpack;
        const ModalEscapeHandler = findLazy(m => m.binds?.length === 1 && m.binds[0] === "esc");

        onceReady.then(() => {
            Common.FluxDispatcher.subscribe("MOBILE_WEB_SIDEBAR_OPEN",  () => { isSidebarOpen = true;  });
            Common.FluxDispatcher.subscribe("MOBILE_WEB_SIDEBAR_CLOSE", () => { isSidebarOpen = false; });
        });

        // ─── NexCord Plugin Registry ─────────────────────────────────────────
        window.NexCord = {
            version: "1.0.0",
            plugins: {},

            registerPlugin(name, plugin) {
                this.plugins[name] = plugin;
                try { plugin.start?.(); } catch(e) { console.error(`[NexCord:${name}] start failed`, e); }
            },

            // Let JS side call Android native helpers
            native: window.VencordMobileNative ?? null,
        };

        // ─── Plugin: MobileSwipeToReply ───────────────────────────────────────
        // Swipe left on a message to reply - Vencord desktop has reply but not mobile swipe
        NexCord.registerPlugin("MobileSwipeToReply", {
            start() {
                let touchStartX = 0, touchStartY = 0, touchTarget = null;
                const SWIPE_THRESHOLD = 60; // px

                document.addEventListener("touchstart", e => {
                    touchStartX = e.touches[0].clientX;
                    touchStartY = e.touches[0].clientY;
                    touchTarget = e.target.closest("[data-list-item-id]") ??
                                  e.target.closest("[class*='message_']");
                }, { passive: true });

                document.addEventListener("touchend", e => {
                    if (!touchTarget) return;
                    const dx = e.changedTouches[0].clientX - touchStartX;
                    const dy = e.changedTouches[0].clientY - touchStartY;
                    if (Math.abs(dx) > SWIPE_THRESHOLD && Math.abs(dy) < 40 && dx < 0) {
                        // Left swipe — trigger reply
                        const btn = touchTarget.querySelector("[aria-label='Reply']") ??
                                    touchTarget.querySelector("[class*='replyButton']");
                        btn?.click();
                        NexCord.native?.vibrate(30);
                    }
                    touchTarget = null;
                }, { passive: true });
            }
        });

        // ─── Plugin: MobileStatusBar ──────────────────────────────────────────
        // Hides the top status bar area padding that causes extra dead space on mobile web
        NexCord.registerPlugin("MobileStatusBar", {
            start() {
                const style = document.createElement("style");
                style.id = "nexcord-statusbar";
                style.textContent = `
                    /* Remove excess top padding Discord adds for PWA status bar */
                    :root { --nexcord-safe-top: env(safe-area-inset-top, 0px); }
                    [class*='app_'] { padding-top: 0 !important; }
                    /* Smooth scrolling everywhere */
                    * { scroll-behavior: smooth; -webkit-overflow-scrolling: touch; }
                    /* Prevent text size bump on rotation */
                    html { -webkit-text-size-adjust: 100%; }
                `;
                document.head.appendChild(style);
            }
        });

        // ─── Plugin: HideBlockedMessages ─────────────────────────────────────
        // Actually removes blocked message elements from DOM (vs just collapsing them)
        NexCord.registerPlugin("HideBlockedMessages", {
            _observer: null,
            start() {
                const hide = () => {
                    document.querySelectorAll("[class*='blockedMessages_']")
                        .forEach(el => { el.style.display = "none"; });
                };
                this._observer = new MutationObserver(hide);
                this._observer.observe(document.body, { childList: true, subtree: true });
                hide();
            },
            stop() { this._observer?.disconnect(); }
        });

        // ─── Plugin: MessageTranslate ─────────────────────────────────────────
        // Long-press any message → "Translate" button using LibreTranslate (free/open)
        NexCord.registerPlugin("MessageTranslate", {
            _apiUrl: "https://libretranslate.com/translate",
            start() {
                document.addEventListener("contextmenu", async e => {
                    const msg = e.target.closest("[class*='message_']");
                    if (!msg) return;
                    const text = msg.querySelector("[class*='messageContent_']")?.innerText;
                    if (!text) return;

                    // Inject a translate option into the context menu after it renders
                    setTimeout(() => {
                        const menu = document.querySelector("[class*='menu_']");
                        if (!menu || menu.querySelector("#nexcord-translate")) return;

                        const item = document.createElement("div");
                        item.id = "nexcord-translate";
                        item.textContent = "🌐 Translate";
                        item.style.cssText = "padding:8px 12px;cursor:pointer;color:var(--text-normal);";
                        item.onclick = async () => {
                            menu.remove();
                            try {
                                const res = await fetch(this._apiUrl, {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ q: text, source: "auto", target: "en" })
                                });
                                const data = await res.json();
                                alert(`[NexCord Translation]\n${data.translatedText ?? "Failed to translate"}`);
                            } catch {
                                alert("[NexCord] Translation service unavailable.");
                            }
                        };
                        menu.appendChild(item);
                    }, 80);
                });
            }
        });

        // ─── Plugin: ReadAllButton ────────────────────────────────────────────
        // Adds a "Mark All Read" FAB button on mobile (buried in desktop sidebar)
        NexCord.registerPlugin("ReadAllButton", {
            start() {
                const btn = document.createElement("button");
                btn.id = "nexcord-read-all";
                btn.innerHTML = "✓✓";
                btn.title = "Mark all as read";
                btn.style.cssText = `
                    position: fixed; bottom: 80px; right: 16px; z-index: 9999;
                    width: 44px; height: 44px; border-radius: 50%; border: none;
                    background: var(--brand-500, #5865f2); color: #fff;
                    font-size: 16px; font-weight: bold; cursor: pointer;
                    box-shadow: 0 2px 8px rgba(0,0,0,.4);
                    display: none;
                `;
                btn.addEventListener("click", () => {
                    try {
                        Vencord.Webpack.Common.GuildReadStateStore
                            ?.markAllChannelsRead?.();
                        NexCord.native?.vibrate(20);
                    } catch {}
                });

                // Only show when there are unreads
                const check = () => {
                    const hasBadge = !!document.querySelector("[class*='numberBadge_']");
                    btn.style.display = hasBadge ? "block" : "none";
                };
                new MutationObserver(check).observe(document.body, { childList: true, subtree: true });

                document.body.appendChild(btn);
            }
        });

        // ─── Plugin: MobileCompactMode ────────────────────────────────────────
        // Reduces padding/margins for more messages visible on small screens
        NexCord.registerPlugin("MobileCompactMode", {
            _enabled: false,
            start() {
                const toggle = document.createElement("style");
                toggle.id = "nexcord-compact";
                // Not injected by default — user enables via NexCord Settings
                window.__nexcordCompactToggle = (on) => {
                    toggle.textContent = on ? `
                        [class*='message_'] { padding-top: 2px !important; padding-bottom: 2px !important; }
                        [class*='contents_'] { line-height: 1.3 !important; }
                        [class*='avatar_'] { width: 32px !important; height: 32px !important; }
                    ` : "";
                    if (on && !document.head.contains(toggle)) document.head.appendChild(toggle);
                };
            }
        });

        // ─── Plugin: CustomFont ───────────────────────────────────────────────
        // Load a Google Font and apply it to Discord's UI
        NexCord.registerPlugin("CustomFont", {
            start() {
                window.__nexcordSetFont = (fontName) => {
                    const id = "nexcord-font";
                    document.getElementById(id)?.remove();
                    if (!fontName) return;
                    const link = Object.assign(document.createElement("link"), {
                        id, rel: "stylesheet",
                        href: `https://fonts.googleapis.com/css2?family=${encodeURIComponent(fontName)}&display=swap`
                    });
                    const style = Object.assign(document.createElement("style"), {
                        id: id + "-apply",
                        textContent: `* { font-family: '${fontName}', sans-serif !important; }`
                    });
                    document.head.append(link, style);
                };
            }
        });

        // ─── Plugin: ImagePreviewExpand ───────────────────────────────────────
        // Tap any image in chat to open it fullscreen without leaving the app
        NexCord.registerPlugin("ImagePreviewExpand", {
            start() {
                const overlay = document.createElement("div");
                overlay.id = "nexcord-img-overlay";
                overlay.style.cssText = `
                    display:none; position:fixed; inset:0; z-index:99999;
                    background:rgba(0,0,0,.92); justify-content:center; align-items:center;
                `;
                const img = document.createElement("img");
                img.style.cssText = "max-width:95vw; max-height:90vh; border-radius:8px; object-fit:contain;";
                overlay.appendChild(img);
                overlay.addEventListener("click", () => { overlay.style.display = "none"; });
                document.body.appendChild(overlay);

                document.addEventListener("click", e => {
                    const target = e.target.closest("[class*='imageWrapper_'] img, [class*='embedMedia_'] img");
                    if (!target) return;
                    img.src = target.src;
                    overlay.style.display = "flex";
                    e.stopPropagation();
                    e.preventDefault();
                }, true);
            }
        });

        // ─── Plugin: MentionSound ─────────────────────────────────────────────
        // Play a subtle ping (Web Audio API) when you get @mentioned - no notification perms needed
        NexCord.registerPlugin("MentionSound", {
            _ctx: null,
            start() {
                this._ctx = new (window.AudioContext || window.webkitAudioContext)();
                const ctx = this._ctx;

                const ping = () => {
                    const osc = ctx.createOscillator();
                    const gain = ctx.createGain();
                    osc.connect(gain); gain.connect(ctx.destination);
                    osc.type = "sine"; osc.frequency.value = 880;
                    gain.gain.setValueAtTime(0.3, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
                    osc.start(); osc.stop(ctx.currentTime + 0.4);
                };

                waitForVencord(() => {
                    Vencord.Webpack.Common.FluxDispatcher?.subscribe("MESSAGE_CREATE", data => {
                        const selfId = Vencord.Webpack.Common.UserStore?.getCurrentUser()?.id;
                        if (selfId && data.message?.mentions?.some(m => m.id === selfId)) {
                            ping();
                        }
                    });
                });
            }
        });

        // ─── Plugin: NexCordSettings ──────────────────────────────────────────
        // Adds a NexCord Settings panel accessible from Discord's User Settings
        NexCord.registerPlugin("NexCordSettings", {
            start() {
                // Inject settings button after Vencord's own tab
                const addSettingsTab = () => {
                    const existing = document.querySelector("[class*='standardSidebarView_']");
                    if (!existing || document.getElementById("nexcord-settings-tab")) return;

                    const tab = document.createElement("div");
                    tab.id = "nexcord-settings-tab";
                    tab.innerHTML = `
                        <div style="padding:10px 16px; cursor:pointer; color:var(--text-normal); border-radius:4px;"
                             onmouseenter="this.style.background='var(--background-modifier-hover)'"
                             onmouseleave="this.style.background=''"
                             onclick="window.__nexcordOpenSettings?.()">
                            🔧 NexCord
                        </div>`;
                    existing.appendChild(tab);
                };

                new MutationObserver(addSettingsTab).observe(document.body, { childList: true, subtree: true });

                window.__nexcordOpenSettings = () => {
                    const panel = document.createElement("div");
                    panel.style.cssText = `
                        position:fixed; inset:0; z-index:99998; background:var(--background-primary);
                        padding:24px; overflow-y:auto; font-family:inherit;
                    `;
                    panel.innerHTML = `
                        <button onclick="this.parentElement.remove()" style="
                            float:right; background:none; border:none; font-size:24px;
                            color:var(--text-normal); cursor:pointer;">✕</button>
                        <h2 style="color:var(--header-primary); margin-bottom:16px;">🔧 NexCord Settings</h2>
                        <label style="display:flex; align-items:center; gap:10px; margin:12px 0; color:var(--text-normal);">
                            <input type="checkbox" id="nc-compact" onchange="window.__nexcordCompactToggle?.(this.checked)">
                            Compact Mode (smaller message spacing)
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; margin:12px 0; color:var(--text-normal);">
                            Custom Font:
                            <input type="text" placeholder="e.g. Inter" id="nc-font"
                                style="background:var(--input-background); color:var(--text-normal);
                                       border:1px solid var(--background-tertiary); border-radius:4px; padding:4px 8px;"
                                onchange="window.__nexcordSetFont?.(this.value.trim())">
                        </label>
                        <div style="margin-top:24px; color:var(--text-muted); font-size:12px;">
                            NexCord v${NexCord.version} — Plugins loaded: ${Object.keys(NexCord.plugins).length}
                        </div>
                    `;
                    document.body.appendChild(panel);
                };
            }
        });

        // ─── VencordMobile back-press handler (original Vendroid behaviour) ───
        window.VencordMobile = {
            onBackPress() {
                try {
                    const ModalEscapeHandler = Vencord.Webpack.findLazy(
                        m => m.binds?.length === 1 && m.binds[0] === "esc");
                    if (ModalEscapeHandler?.action?.() === false) return true;
                } catch {}

                const quickCssWin = window.__VENCORD_MONACO_WIN__?.deref();
                if (quickCssWin && !quickCssWin.closed) {
                    quickCssWin.close();
                    delete window.__VENCORD_MONACO_WIN__;
                    return true;
                }

                if (!isSidebarOpen) {
                    try {
                        Vencord.Webpack.Common.FluxDispatcher.dispatch({ type: "MOBILE_WEB_SIDEBAR_OPEN" });
                    } catch {}
                    return true;
                }
                return false;
            }
        };

        // ─── Inject CSS ───────────────────────────────────────────────────────
        document.addEventListener("DOMContentLoaded", () => {
            // Try NexCord CSS first, fallback to Vencord
            const href = "https://github.com/NexCord/NexCord/releases/latest/download/nexcord.css";
            const fallback = "https://github.com/Vendicated/Vencord/releases/download/devbuild/browser.css";

            const link = Object.assign(document.createElement("link"), {
                rel: "stylesheet", type: "text/css", href
            });
            link.onerror = () => { link.href = fallback; };
            document.documentElement.appendChild(link);
        }, { once: true });

        console.log(`%c NexCord v${NexCord.version} loaded ✓ `, "background:#5865f2;color:#fff;border-radius:4px;padding:2px 6px;");
    });
})();
